cd('/home/umr9753/JR/MEG_StringsNumbers/scripts/data_processing');
%cfg_exp = add_toolboxes('harddrive');
% cd('/media/DATA/Pro/Projects/Paris/Categorization/MEG_StringsNumbers/scripts/data_processing/');
cfg_exp = add_toolboxes('imen');
addpath('/home/umr9753/JR/Dropbox/JR_toolbox/');

%-- get experiment's details, create links etc
cfg_exp = exp_details(cfg_exp);


%-- create links
% create_links(cfg_exp);
% %-- maxfilter sss correction
% for s = 1:length(cfg_exp.subjects)
%     disp(s);
%     [cfg_exp.maxfilter.status{s}  cfg_exp.maxfilter.log{s}]= prep                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     rocess_maxfilter(cfgt_exp,cfg_exp.subjects{s});
% end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PRE PROCESSING %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-- check ECG/EOG channels
for s = 1:length(cfg_exp.subjects_name)
    disp(s)
    cfg             = [];
    cfg.main_dir    = cfg_exp.main_dir;
    cfg.chantypes   = cfg_exp.chantypes;
    files           = cfg_exp.subjects_files{s};
    name           = cfg_exp.subjects_name{s};
    checkup_ecgeog(cfg, files,name); 
end

%-- ECG/EOG detection
for s = length(cfg_exp.subjects_name):-1:1
    if isempty(dir([cfg_exp.main_dir 'data/preprocessed/' cfg_exp.subjects_name{s} '_component.mat']))
    disp(s)
    plot            = true;
    cfg             = [];
    cfg.main_dir    = cfg_exp.main_dir;
    cfg.chantypes   = cfg_exp.chantypes;
    cfg.layout      = cfg_exp.layout_chantype;
    files           = cfg_exp.subjects_files{s};
    preprocess_ecgeog(cfg, files, plot);
    end
end
%%%%%%%%%%%%%% REDO SUBJECT "AS" MAIN 7 COMPONENT ******

%-- manual check
for s = 1:length(cfg_exp.subjects_name)
    name                = cfg_exp.subjects_name{s};
    files               = cfg_exp.subjects_files{s};
    cfg                 = [];
    cfg.create(1).max   = 7;
    cfg.create(1).name  = 'mean_ecg_ica';
    cfg.create(1).base  = 'ecg_ica';
    cfg.create(1).exp   = ones(length(cfg_exp.subjects_files{s})); % take all mean
    
    cfg.create(2).max   = 7;
    cfg.create(2).name  = 'mean_ecg_chan';
    cfg.create(2).base  = 'ecg_chan';
    cfg.create(2).exp   = ones(length(cfg_exp.subjects_files{s})); % take all mean
    
    cfg.create(3).max   = 7;
    cfg.create(3).name  = 'mean_eog_v_chan';
    cfg.create(3).base  = 'eog_v_chan';
    cfg.create(3).exp   = ones(length(cfg_exp.subjects_files{s})); % take all mean
    
    figure(s);clf;set(gcf,'color','w', 'name', cfg_exp.subjects_name{s},'position',[1 1 1900 894]);
    preprocess_checkart(cfg_exp, files, name,cfg);
    export_fig([cfg_exp.main_dir 'data/figures/artifacts_correction/img_' cfg_exp.subjects_name{s} '_components.png']);
end


% plot all correction results
close all;
for s = 1:length(cfg_exp.subjects_name)
    name                = cfg_exp.subjects_name{s};
    files               = cfg_exp.subjects_files{s};
    arts = {'ecg_ica', 'ecg_chan', 'eog_v_chan', 'mean_ecg_ica', 'mean_ecg_chan', 'mean_eog_v_chan'};
    for art = 1:length(arts)
        cfg                 = [];
        cfg.art = arts{art};
        figure(s);clf;set(gcf,'color','w', 'name', cfg_exp.subjects_name{s},'position',[1 1 1900 894]);
        preprocess_check_art_all(cfg_exp, name,cfg);
        export_fig([cfg_exp.main_dir 'data/figures/artifacts_correction/img_' cfg_exp.subjects_name{s} '_' cfg.art '.png']);
    end
end

%% preprocessing
for s = 1:length(cfg_exp.subjects_name)
    files   = cfg_exp.subjects_files{s};
    preprocess_segmentpreproc(cfg_exp, files);
end

%% concatenate runs
for s = 1:length(cfg_exp.subjects_name)
    name           = cfg_exp.subjects_name{s};
    files          = cfg_exp.subjects_files{s};
    preprocess_concatenate(cfg_exp, files, name, 'preproc');
end


%% associate behavioral results to meg data
for s = 1:length(cfg_exp.subjects_name)
    bhv_name       = cfg_exp.subjects_behavior{s};
    meg_name       = cfg_exp.subjects_name{s};
    get_behavior(cfg_exp,bhv_name,meg_name);
end 


%% artefact detection
for s = 1:length(cfg_exp.subjects_name)
    files   = cfg_exp.subjects_files{s};
    preprocess_muscle(cfg_exp, files);
    preprocess_15Hz(cfg_exp, files);
end

%% concatenate artefacts
for s = 1:length(cfg_exp.subjects_name)
    name           = cfg_exp.subjects_name{s};
    files          = cfg_exp.subjects_files{s};
    preprocess_concatenate(cfg_exp, files, name, 'pow_lower15Hz');
    preprocess_concatenate(cfg_exp, files, name, 'muscle');
end

%% summarize artifacts and add them to behavioral file
for s = 1:length(cfg_exp.subjects_name)
    name           = cfg_exp.subjects_name{s};
    figure;clf;set(gcf,'color','w', 'position', [1 25 1900 894]);
    preprocess_label_artifacts(cfg_exp, name);
    export_fig([cfg_exp.main_dir 'data/figures/outliers/' name '_outliers.png']);
end

%% Time frequency preprocessing 
for s = 1:length(cfg_exp.subjects_name)
    files   = cfg_exp.subjects_files{s};
    preprocess_segmentpreproc_tf(cfg_exp, files);
end
% REDO SUBJECT 13??

%-- concatenate time frequency runs
for s = 13:length(cfg_exp.subjects_name)
    name           = cfg_exp.subjects_name{s};
    files          = cfg_exp.subjects_files{s};
    preprocess_concatenate_tf(cfg_exp, files, name);
end



%% realign to get response-lock ERPs
for s = 1:length(cfg_exp.subjects_name)
    disp(s);
    name    = cfg_exp.subjects_name{s};
    %-- path
    pathX = [cfg_exp.main_dir 'data/preprocessed/'];
    pathB   = [cfg_exp.main_dir 'data/behavior/' name '_behaviorMEG.mat'];
    
    %-- Load data details
    clear data_concatenated Xdim time
    load([pathX name '_preproc.mat'],'data_concatenated');
    Xdim = data_concatenated.dims;
    time = data_concatenated.time{1};
    %-- load MEG data
    clear XT XR
    XT = binload([pathX name '_preproc.dat'], Xdim); % Target locked
    %-- load behavioral (ttl+response)
    clear trials
    load(pathB, 'trials');

    %-- realign
    XR = []; % response locked
    for t = 1920:-1:1
        %-- find RT
        rt=find(time>=trials(t).RT_MEG,1);
        %-- realign from TOI
        if ~isnan(rt)
            pre = NaN(size(XT,1),length(time)-rt);
            post = NaN(size(XT,1),rt);
            %-- add trial
            XR(:,:,t) = cat(2,pre, XT(:,:,t), post);
        else
            XR(:,:,t) = NaN(size(XT,1),length(time)*2);
        end
    end
    %-- select time_window
    Rtime = linspace(-length(time),length(time),2*length(time))/data_concatenated.fsample;
    toi = find(Rtime>=-1.500 & Rtime<=1.000);
    Rtime = Rtime(toi);
    XR = XR(:,toi,:);
    %-- save
    for t = 1:1920
        data_concatenated.time{t} = Rtime;
    end
    data_concatenated.dims = size(XR);
    data_concatenated.trial = [pathX name '_preproc_Rlock.dat'];
    save([pathX name '_preproc_Rlock.mat'],'data_concatenated');
    binsave([pathX name '_preproc_Rlock.dat'], XR);
end




%% realign to get response-lock TFs
for s = 1:length(cfg_exp.subjects_name)
    disp(s);
    name    = cfg_exp.subjects_name{s};
    %-- path
    pathX = [cfg_exp.main_dir 'data/preprocessed/'];
    pathB   = [cfg_exp.main_dir 'data/behavior/' name '_behaviorMEG.mat'];
    
    %-- Load data details
    clear data_concatenated Xdim time
    load([pathX name '_preproc_tf.mat'],'data_concatenated');
    Xdim = data_concatenated.dims;
    time = data_concatenated.time;
    nt = length(data_concatenated.time);
    nf = length(data_concatenated.freq);
    %-- load MEG data
    clear XT XR
    XT = binload([pathX name '_preproc_tf.dat'], Xdim); % Target locked
    %-- load behavioral (ttl+response)
    clear trials
    load(pathB, 'trials');

    %-- realign
    XR = []; % response locked
    for t = 1920:-1:1
        if mod(t,192)==0, fprintf('*'); end
        %-- find RT
        rt=find(time>=trials(t).RT_MEG,1);
        %-- realign from TOI
        if ~isnan(rt)
            pre = NaN(size(XT,2),nf,length(time)-rt);
            post = NaN(size(XT,2),nf,rt);
            %-- add trial
            XR(t,:,:,:) = cat(3,pre, squeeze(XT(t,:,:,:)), post);
        else
            XR(t,:,:,:) = NaN(size(XT,2),nf,length(time)*2);
        end
    end
    %-- select time_window
    fsample = 1/median(time(2:end)-time(1:(end-1)));
    data_concatenated.fsample = fsample;
    Rtime = linspace(-length(time),length(time),2*length(time))/data_concatenated.fsample;
    toi = find(Rtime>=-1.500 & Rtime<=1.000);
    Rtime = Rtime(toi);
    XR = XR(:,:,:,toi);
    %-- save
    data_concatenated.time = Rtime;
    data_concatenated.dims = size(XR);
    data_concatenated.trial = [pathX name '_preproc_tf_Rlock.dat'];
    save([pathX name '_preproc_tf_Rlock.mat'],'data_concatenated');
    binsave([pathX name '_preproc_tf_Rlock.dat'], XR);
end

%% Clean up

for s = 1:length(cfg_exp.subjects_name)
    name           = cfg_exp.subjects_name{s};
    files          = cfg_exp.subjects_files{s};
%     delete_files([cfg_exp.main_dir 'data/preprocessed/'], files, '*muscle*');
%     delete_files([cfg_exp.main_dir 'data/preprocessed/'], files, '*preproc.*');
%     delete_files([cfg_exp.main_dir 'data/preprocessed/'], files, '*pow_lower15Hz*');
end