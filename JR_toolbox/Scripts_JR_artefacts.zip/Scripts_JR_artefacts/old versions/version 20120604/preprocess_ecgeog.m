function [cfg_art components] = preprocess_ecgeog(cfg_exp, files, plot)
% [cfg_art components] = preprocess_ecgeog(cfg_exp, files, plot)
% (c) JeanRémi King 2012
if nargin == 2,
    plot = false;
end
tic
for file = 1:length(files)
    component                   = []; % initialize
%     try
        
        cfg_art                 = [];
        cfg_art.dir             = [cfg_exp.main_dir 'data/preprocessed/'];
        cfg_art.chantypes       = cfg_exp.chantypes;
        cfg_art.dataset         = [cfg_exp.main_dir 'data/sss/' files{file} '_sss.fif'];
        
        evalc('hdr              = ft_read_header(cfg_art.dataset);'); % silence
        
        %-- ecg
        disp(['-------- Compute ECG ' num2str(file) '/' num2str(length(files)) '-----------']);
        cfg_art.hdr             = hdr;
        cfg_art.artchan         = find(cell2mat(cellfun(@(x) ~isempty(findstr('ECG',x)), hdr.label, 'UniformOutput', false)));
        cfg_art.prestim         = .100; % in ms
        cfg_art.poststim        = .700;
        cfg_art.threshold       = 3.5; % in STD
        component.ecg           = ft_jr_art(cfg_art);
        if plot
            figure(1);clf;
            ft_jr_art_plot(component.ecg);
            set(gcf,'position', [2    250 560 700], 'name', ['ecg ' files{file}]);
        end
        
        %-- eog 1
        disp(['-------- Compute EOG1 ' num2str(file) '/' num2str(length(files)) '-----------']);
        cfg_art.artchan         = find(cell2mat(cellfun(@(x) ~isempty(findstr('EOG',x)), hdr.label, 'UniformOutput', false)));
        cfg_art.artchan         = cfg_art.artchan(1);
        cfg_art.prestim         = .500;
        cfg_art.poststim        = .500;
        cfg_art.threshold       = 3.5;
        component.eogh          = ft_jr_art(cfg_art);
        if plot
            figure(2);clf;
            ft_jr_art_plot(component.eogh);
            set(gcf,'position', [2    250 560 700], 'name', ['eogh ' files{file}]);
        end
        
        
        %-- eog 2
        disp(['-------- Compute EOG2 ' num2str(file) '/' num2str(length(files)) '-----------']);
        cfg_art.artchan         = find(cell2mat(cellfun(@(x) ~isempty(findstr('EOG',x)), hdr.label, 'UniformOutput', false)));
        cfg_art.artchan         = cfg_art.artchan(2);
        component.eogv          = ft_jr_art(cfg_art);
        if plot
            figure(3);clf;
            ft_jr_art_plot(component.eogv);
            set(gcf,'position', [2    250 560 700], 'name', ['eogv ' files{file}]);
        end
        %-- save
        disp(['-------- SAVE ' num2str(file) '/' num2str(length(files))  '-----------']);
        save([cfg_exp.main_dir 'data/preprocessed/' files{file} '_component.mat'], 'component', 'cfg*');
        components(file)        = component;
%     catch
%         warning(['error on ' files{file} ]);
%         pause;
%     end
end
disp('-------- SAVE all -----------');
save([cfg_exp.main_dir 'data/preprocessed/' files{file}(1:2) '_components.mat'], 'components', 'cfg*');

toc


