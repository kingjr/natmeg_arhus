function  ft_jr_art_plot(component,cfg)
% ft_jr_art_plot(component[,cfg])
% 
% plot artefact detection and correction results 
% 
% requires: ft_jr_art.m
%--------------------------------------------------------------------------
% Jean-Rémi King
%--------------------------------------------------------------------------


if nargin == 1
    cfg = [];
end
% automatically determines scale
if ~isfield(cfg,'scale'), 
    if length(component.cfg.chantypes) == 1 && strcmpi(component.label{1}(1), 'E')
        cfg.scale = [-1 1] .* 10^-3;
    elseif length(component.cfg.chantypes) == 1 && strcmpi(component.label{1}(1:3), 'MEG')
        cfg.scale = [-1 1] .* 10^-11;
    elseif length(component.cfg.chantypes) == 2 && strcmpi(component.label{1}(1:3), 'MEG')
         cfg.scale = [[-1 1] .* 10^-11; [-2 2] .* 10^-12];
    end
end

clf;set(gcf,'name',component.cfg.dataset,'color','w');
%-- artefact finding
subplot(5,1,1);cla;hold on;
plot(component.artchan_trial,'b');
scatter(component.cfg_art.all_trl(:,1), repmat(median(component.artchan_trial),length(component.cfg_art.all_trl),1),'*r')
axis([0 length(component.artchan_trial) ylim]);
title('artefact channel and artefact detection');box off;
for chantype = 1:length(component.cfg.chantypes)
    %-- average artefact
    subplot(5,length(component.cfg.chantypes),length(component.cfg.chantypes)*1+chantype);cla;
    plot(component.time, component.avg(component.cfg.artchan,:),'b');
    axis([min(component.time) max(component.time) ylim]);
    title(['channel: ' num2str(component.cfg.artchan)]);box off;
    %-- average ERP
    subplot(5,length(component.cfg.chantypes),length(component.cfg.chantypes)*2+chantype);cla;
    %imagesc(component.time,component.cfg.chantypes{chantype},component.avg,cfg.scale(chantype,:));%normal
    imagesc(component.time,component.cfg.chantypes{chantype},component.avg-repmat(nanmean(component.avg,2),1,size(component.avg,2)),cfg.scale(chantype,:));%normalize
    title(['ERP ' num2str(chantype)]);box off;
    %-- correlation & latent values
    subplot(5,length(component.cfg.chantypes),length(component.cfg.chantypes)*3+chantype);cla; hold on;
    scatter(abs(component.corr(chantype).R),component.pca(chantype).latent, '+b');
    scatter(abs(component.corr(chantype).R(1:size(component.rm_components{chantype},1))),component.pca(chantype).latent(1:size(component.rm_components{chantype},1)), 'r', 'filled');
    axis([0 1 0 1]);box off;xlabel('R'); ylabel('Latent');
    %-- correction
    subplot(5,length(component.cfg.chantypes),length(component.cfg.chantypes)*4+chantype);cla;
    imagesc(component.time,component.cfg.chantypes{chantype},component.clear_art(component.cfg.chantypes{chantype},:),cfg.scale(chantype,:));
    title(['Corrected ERP ' num2str(chantype)]);box off; 
end
return