function trl = ft_jr_ecg_trialfun(cfg)
%% trl = ft_jr_ecg_trialfun(cfg)
% function that automatically detect the ECG beats, and gives back the fieldtrip trial structure
% - inputs
%   - cfg.
% - output
%   - trl structure (matrix n trials x 3 colums)
% -------------------------------------------------------------------------
% requires 
%   - fieldtrip 2011
%   - (MNE toolbox)
% -------------------------------------------------------------------------
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (c) 2011 Jean-Rémi KING
% jeanremi.king+matlab@gmail.com
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global threshold artchan_trial
%-- trialfun function used in ft_definetrial to realign the ecg to the
% heart beat
%-- requires cfg.dataset
if ~isfield(cfg, 'dataset'),    error('needs cfg.dataset! (file path)');        end
if ~isfield(cfg, 'artchan'),    error('needs cfg.artchan! (artefact channel)'); end
if ~isfield(cfg, 'art_prestim'),    cfg.prestim     = .100;                     end % select time before heart beat
%if ~isfield(cfg, 'art_poststim'),   cfg.poststim    = .550;                         end % select time after heart beat
if ~isfield(cfg, 'threshold'),  cfg.threshold   = 5;                            end % in STD
if ~isfield(cfg, 'continuous'), cfg.continuous  = 'yes';                        end % continuous data
if ~isfield(cfg, 'hpfilter'),   cfg.hpfilter    = 'yes';                        end % remove shifts
if ~isfield(cfg, 'hpfreq'),     cfg.hpfreq      = 2;                            end % high pass filter freq
if ~isfield(cfg, 'maxartfreq'), cfg.maxartfreq  = .150;                         end % max s between heart beat 
if ~isfield(cfg, 'minnb'),      cfg.minnb       = 5;                            end % minimum number of artefact
%-- select ecg chan only
cfg_art                     = cfg;
cfg_art.channel             = cfg.artchan;
%-- load data
disp('reads continuous data...');
while 1
    evalc('data_ecg                    = ft_preprocessing(cfg_art);');
    %-- build dipole
    artchan_trial = nanmean(data_ecg.trial{1}(1:2:end,:)-data_ecg.trial{1}(2:2:end,:),1);
    %-- find pulse
    disp('finds heart beats...');
    data_ecg.pulse              = find(abs(artchan_trial) > (mean(artchan_trial)+cfg_art.threshold*std(artchan_trial)));
    %-- remove consecutive points: take only points that are further away
    %than .150 s (high frequency heart beats)
    data_ecg.pulse              = data_ecg.pulse((data_ecg.pulse(2:end)-data_ecg.pulse(1:(end-1))) >  cfg.maxartfreq*data_ecg.fsample);
    if isfield(cfg,'rmsamples'),    data_ecg.pulse              = data_ecg.pulse(~ismember(data_ecg.pulse,cfg.rmsamples)); end
    
    if cfg_art.threshold < 1
        warning('!PROBLEM! NO ARTEFACT FOUND');
        threshold = NaN;
        trl = NaN;
        return
    elseif length(data_ecg.pulse) >= cfg.minnb 
        break
    else
        cfg_art.threshold = cfg_art.threshold * 2/3;
        warning(['! NO ARTEFACT FOUND: => diminish threshold to ' num2str(cfg_art.threshold)]);
    end
end

%-- calculate post stim according to median time across beats
if ~isfield(cfg, 'poststim') || strcmp(cfg.poststim, 'auto')
    cfg.poststim = median(data_ecg.pulse(2:end)-data_ecg.pulse(1:(end-1)))/data_ecg.fsample- cfg.prestim ;
end
%-- final triggers
trl = [...
    data_ecg.pulse-(cfg.prestim * data_ecg.fsample); ...
    data_ecg.pulse+(cfg.poststim * data_ecg.fsample); ...
    repmat(-cfg.prestim .* data_ecg.fsample,1,length(data_ecg.pulse))]'; % why divide by 10???
%-- remove artefact at beginning and end
trl = trl(intersect(find(trl(:,1)>(cfg.prestim*data_ecg.fsample)), find(trl(:,2)<(data_ecg.sampleinfo(2)-cfg.poststim*data_ecg.fsample))),:);

threshold = cfg_art.threshold;
end
