function data_art = ft_jr_art(cfg)
%% data_raw = ft_jr_ecgeog(cfg)
% automatically removes artefacts based on specificity (correlations) and
% sensitivity (% variance explained)
% -------------------------------------------------------------------------
% (c) 2012 Jean-Rémi KING
% contact: jeanremi.king+matlab@gmail.com
% -------------------------------------------------------------------------
% The method is based on 
%       1. finding artefact based on a given channel, or a set of channels
%       2. building a template of stereotyped artefact 
%       3. finding the combination of channels that explains most of the
%       template artefact
%       4. regressing out this combination from the data
%       5. verifying on a maximally different dataset whether it works
%
% The non traditional features are:
%       - stereotyped artefacts are based on median across trials and not 
%       means as the M/EEG spreads in a log space, one trial can 
%       dramatically affects the steretopyed pattern. 
%       - stereotyped artefacts are normalized by the MAD, in order to 
%       avoid a few bad channels to capture most of the variance.
%       - the correlations between the principal components and the
%       artefacted channels can be used to see whether the corrected
%       topography is actually specific to the artefact. This is mainly
%       useful in MEG, as in EEG topographies are largely overlapping.
% -------------------------------------------------------------------------
% inputs
%   - cfg.dataset           => path of dataset
%   - cfg.chantypes         => cells of chantypes       (default => all)
%   - cfg.artchan           => artefacted channel (is 2D, takes difference, if 2Dx2D, takes mean difference)
%   - cfg.dataformat        =>                          (default => 'neuromag')
%   - cfg.headerformat      =>                          (default => 'neuromag')
%   - cfg.prestim           => cut before ecg           (default => .2)
%   - cfg.poststim          => cut after ecg            (default => .5)
%   - cfg.dividetrial       => divide computation       (default => by 1)
%   - cfg.corr_thresh       => corr(PC,ecg) threshold   (default => .1)
% output
%   - data                  => structure containing continuous FT data
% -------------------------------------------------------------------------
% requires
%   - stats toolbox         should be change for independence
%   - Fieldtrip:            http://fieldtrip.fcdonders.nl/
% -------------------------------------------------------------------------
% modifications
%   - 2012 05 22            JRK: adapt to EEG: add dipoles
%                               preproc steps.
%                               correlation become optional
%                               art_chan becomes globally available
% -------------------------------------------------------------------------
% to be done
%   - making optional checkup on independent data
%   - cleaning script: not cdg specific anymore, add commentaries, get ridd
%   off of multiple cfg
%   - add help to apply correction on future data
%   - redo the help to complete all cfg fields
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ====================================================================
% ============================ parameters ============================
% ====================================================================

%-- check fields
if ~isfield(cfg,'dataset'),     error('needs cfg.dataset');                 end
if ~isfield(cfg,'artchan'),     error('cfg.artchan is needed!');            end
%------------------------- read header -----------------------------------
disp(['Read ' cfg.dataset]);
if ~isfield(cfg,'hdr'),         evalc('hdr = ft_read_header(cfg.dataset);');
else
                                evalc('hdr = cfg.hdr;')
end
if ~isfield(cfg,'channels'),    cfg.channels    = 1:hdr.nChans;             end % vector specifying channels to analyze
if ~isfield(cfg,'chantypes'),   cfg.chantypes   = {cfg.channels};           end % cells dividing types of sensors (gradiometers, etc)
%-- finds ecg channels
if ~isfield(cfg,'headerformat'),cfg.headerformat= 'neuromag_mne';           end
if ~isfield(cfg,'dataformat'),  cfg.dataformat  = 'neuromag_mne';           end
if ~isfield(cfg,'prestim'),     cfg.prestim     = .200;                     end % time to keep before artefact
if ~isfield(cfg,'poststim'),    cfg.poststim    = 1.000;                    end % time to keep after artefact
if ~isfield(cfg,'dividetrial'), cfg.dividetrial = 1;                        end % divide the computation by n trials for memory issue
if ~isfield(cfg,'corr_thresh'), cfg.corr_thresh = .05;                      end % correlation probability between ECG and PC, 
if ~isfield(cfg,'latent_thresh'),cfg.latent_thresh=.15;                     end % minimum variance explained by component (in %)
if ~isfield(cfg,'artnb'),       cfg.artnb       = 100;                      end % max number of artefacts to keep
if ~isfield(cfg,'threshold'),   cfg.threshold   = 3.5;                      end % in STD
if ~isfield(cfg,'max_comp'),    cfg.max_comp    = 3;                        end % maximum principal components to be removed
if ~isfield(cfg,'norm'),        cfg.norm        = 'medmad';                 end % normalization using median and mad
if ~isfield(cfg,'apply_corr'),  cfg.apply_corr  = true;                     end % apply correlation analyses on components across time of specificity measure.
cfg.trialfun                    = 'ft_jr_ecg_trialfun';                         % get heart beat as triggers
cfg.trial                       = 1:cfg.artnb;

% ====================================================================
% ========================== main function ===========================
% ====================================================================

tic
global threshold artchan_trial % get threshold back from ft_jr_trialfun
threshold = cfg.threshold;


%--------------------- 1. find artefacted moments -------------------------
disp('Find artifact timing...');
evalc('cfg_art              = ft_definetrial(cfg);') % silence output
if isnan(threshold), data_art = []; warning('could not find artefact'); return; end
cfg.threshold               = threshold; % update threshold
cfg_art.all_trl             = cfg_art.trl;% only focus on n first artefacts (for memory and speed issues)
cfg_art.trl                 = [...
    cfg_art.trl(:,1) - cfg.prestim .* hdr.Fs,...
    cfg_art.trl(:,1) + cfg.poststim .* hdr.Fs,...
    repmat(cfg.prestim + cfg.poststim .* hdr.Fs, size(cfg_art.trl,1),1)];
% remove triggers that overlaps before zero
if cfg_art.trl(1,1) <= 0
    start = find(cfg_art.trl(:,1)>0,1);
else
    start = 1;
end
cfg_art.trl                 = cfg_art.trl(start:min(length(cfg_art.trl),cfg.artnb),:); 
cfg_art.prestim             = cfg.prestim;
cfg_art.poststim            = cfg.poststim;

%----------------------- 2. Get artefacted ERP ----------------------------
disp(['Average artifacts using ' cfg.norm '...']);
evalc('data_art             = ft_preprocessing(cfg_art);'); % silence output
switch cfg.norm
    case 'medmad'
        %-- get median absolute deviation for each channel in order to
        %prevent crap channel from exploding the variance
        chan_mad    = mad(cell2mat(data_art.trial),1,2);
        %-- keep meaningfull scaling
        chan_mad    = chan_mad / median(chan_mad);
        chan_mad(chan_mad==0) = 1; % to avoid NaNs
        %-- median across trials
        data_art.avg= nanmedian(reshape(cell2mat(cellfun(@(x) x, data_art.trial, 'UniformOutput', false)),[length(data_art.label), size(data_art.trial{1},2), length(data_art.trial)]),3);
        %-- divide by chan_mad
        data_art.avg=data_art.avg./repmat(chan_mad,1,size(data_art.avg,2));
    case 'zscore'
        % tbd
end
data_art.time               = data_art.time{1};
data_art.trial              = []; % clear trials from memory

 
%---------------------- 3. Compute artefact pca ---------------------------
for chantype = 1:length(cfg.chantypes) % independently for each sensor
    disp(['Computes pca on chans ' num2str(chantype) '...']);
    [data_art.pca(chantype).coeff...
        data_art.pca(chantype).score...
        data_art.pca(chantype).latent]= princomp(data_art.avg(cfg.chantypes{chantype},:)');
    % latent into explained variance
    data_art.pca(chantype).latent = data_art.pca(chantype).latent ./ sum(data_art.pca(chantype).latent);
end

%------------------------ 4. Get continuous signal ------------------------
cfg_raw                     = cfg;
cfg_raw.headerformat        = cfg.headerformat;
cfg_raw.dataformat          = cfg.dataformat;
cfg_raw.dataset             = cfg.dataset;
cfg_raw.corr_with           = [(length(cfg_art.all_trl) - min(length(cfg_art.trl),cfg.artnb) +1) min(length(cfg_art.all_trl) - min(length(cfg_art.trl),cfg.artnb) + cfg.artnb,length(cfg_art.all_trl))];


disp(['Read continuous signal on trials ' num2str(cfg_raw.corr_with) 'for independent correlations']);

cfg_raw.trl                 = [...
    cfg_art.all_trl(cfg_raw.corr_with(1),1),...
    cfg_art.all_trl(cfg_raw.corr_with(2),2),...
    cfg_art.all_trl(cfg_raw.corr_with(2),2)-cfg_art.all_trl(cfg_raw.corr_with(1),1)];
evalc('data_raw             = ft_preprocessing(cfg_raw);');
data_art.artchan_trial      = artchan_trial;

%-- get maximally independent average artefact to be correlated with
cfg_raw_seg                 = cfg_raw;
cfg_raw_seg.trl             = cfg_art.all_trl(cfg_raw.corr_with(1):cfg_raw.corr_with(2),:);
cfg_raw_seg.trl                 = [...
    cfg_raw_seg.trl(:,1) - cfg.prestim .* hdr.Fs,... 
    cfg_raw_seg.trl(:,1) + cfg.poststim .* hdr.Fs,...
    repmat(cfg.prestim + cfg.poststim .* hdr.Fs, size(cfg_raw_seg.trl,1),1)];
cfg_raw_seg.prestim         = cfg.prestim;
cfg_raw_seg.poststim        = cfg.poststim;


evalc('data_raw_seg         = ft_preprocessing(cfg_raw_seg);');
data_raw_seg.avg            = nanmedian(reshape(cell2mat(cellfun(@(x) x, data_raw_seg.trial, 'UniformOutput', false)),[length(data_raw_seg.label), size(data_raw_seg.trial{1},2), length(data_raw_seg.trial)]),3);
data_raw_seg.trial          = [];
data_raw_seg.time           = data_raw_seg.time{1};

%--------------- 5. Correlate PC with artefacted channel ------------------
for chantype = 1:length(cfg.chantypes)
    disp(['Computes correlations on chans ' num2str(chantype) '...']);
    
    %-- rotate data into PC space
    data_raw.components(cfg.chantypes{chantype},:) = data_art.pca(chantype).coeff'*data_raw.trial{1}(cfg.chantypes{chantype},:);
    
    %-- Compute components correlation with artefacted channel
    if cfg.apply_corr
    [data_art.corr(chantype).R data_art.corr(chantype).p]  = corr(...
        data_raw.components(cfg.chantypes{chantype},:)',...
        artchan_trial(:,cfg_art.all_trl(cfg_raw.corr_with(1),1):cfg_art.all_trl(cfg_raw.corr_with(2),2))');
    else
        data_art.corr(chantype).R = NaN(length(cfg.channels),1);
        data_art.corr(chantype).p = NaN(length(cfg.channels),1);
    end
    
    %-- Find to-be-removed components 
    data_art.rm_corr{chantype}          = find(abs(data_art.corr(chantype).p(1:cfg.max_comp)) <= .05);
    data_art.rm_pca{chantype}           = find(data_art.pca(chantype).latent >= cfg.latent_thresh) ;
    data_art.rm_components{chantype}    = intersect(data_art.rm_corr{chantype}, data_art.rm_pca{chantype});
    disp(['Removed ' num2str(length(data_art.rm_components{chantype})) ' component(s) on chans ' num2str(chantype) ]);
    %-- Find to-be-kept components
    data_art.keep_components{chantype}  = setdiff(1:size(data_art.pca(chantype).coeff,1),data_art.rm_components{chantype});
    %-- Compute difference
    data_art.clear_comp{chantype}       = zeros(length(data_art.rm_components{chantype}),size(data_art.pca(chantype).coeff,1));
    data_art.clear_comp{chantype}       = cat(2,data_art.clear_comp{chantype}',data_art.pca(chantype).coeff(:,data_art.keep_components{chantype}))';
    
    %-- Compute correction on average artefact
    data_art.clear_art(cfg.chantypes{chantype},:)     = ...
        data_art.pca(chantype).coeff*...
        data_art.clear_comp{chantype}*...
        data_raw_seg.avg(cfg.chantypes{chantype},:);
end

%---------------------------- save components -----------------------------
disp(['Export results...']);
data_art.cfg        = cfg;
data_art.cfg_art    = cfg_art;
data_art.cfg_raw    = cfg_raw;
data_art.cfg_raw_seg= cfg_raw_seg;
data_art.avg2        = data_raw_seg.avg;
toc 
return