function f = preprocess_check_pca(cfg_exp,files)
% handles = preprocess_check_pca(cfg_exp,files)
% (c) JeanRémi KING 2012

load([cfg_exp.main_dir 'data/preprocessed/' files{1}(1:2) '_components.mat'], 'components', 'cfg*');
for file = 1:length(files)
    % recalculate PCA
    try
        figure(1);clf;
        ft_jr_art_plot(components(file).ecg);   f.ecg(file) = gcf;
        set(gcf,'position', [2    250 560 700], 'name', cfg_exp.subjects.files{s}{file});
    end
    try
        figure(2);clf;
        ft_jr_art_plot(components(file).eogv);  f.eogv(file) = gcf;
        set(gcf,'position', [560  250 560 700], 'name', cfg_exp.subjects.files{s}{file});
    end
    try
        figure(3);clf;
        ft_jr_art_plot(components(file).eogh);  f.eogh(file) = gcf;
        set(gcf,'position', [1120 250 560 700], 'name', cfg_exp.subjects.files{s}{file});
        
    end
    pause;
end
save([cfg_exp.main_dir 'data/preprocessed/' files{1}(1:2) '_components_checked.mat'], 'components', 'cfg*');