clear
clc;
cd ('/mnt/DSuppl/Documents/Data/Shared projects/Controls-Merikle/Manip2 avril 2012 explicit strategy/Merikle/EEG/EGI');

%% select subject
answer = inputdlg('Subject number');
isub = str2double(answer{1});

%%
cfg                 = [];
cfg.dataset         = ['sujet',num2str(isub),'.raw'];
cfg.headerformat    = '';
cfg.dataformat      = '';
%find(cell2mat(cellfun(@(x) ~isempty(findstr('EOG',x)), hdr.label, 'UniformOutput', false)));
hdr = ft_read_header(cfg.dataset);

cfg_trial = [];
cfg_trial.dataset             = ['sujet',num2str(isub),'.raw'];
cfg_trial.trialdef.prestim    = 0.4;
cfg_trial.trialdef.poststim   = 0.9;
cfg_trial.trialdef.eventtype  = 'trigger';
cfg_trial.trialdef.eventvalue = 'tgt+';
cfg_trial = ft_definetrial(cfg_trial); % define trials timing
%%% Identify pauses
% reject data from pauses for the calculation of the EOG erp
pause_samples = [];
find_pause = find(diff(cfg_trial.trl(:,1))>1000);
pause_samples = [pause_samples 1:cfg_trial.trl(1,1)];
for ipause = 1:length(find_pause)-1
    pause_samples = [pause_samples cfg_trial.trl(find_pause(ipause),2):cfg_trial.trl(find_pause(ipause)+1,1)];
end
pause_samples = [pause_samples cfg_trial.trl(end,2):hdr.nSamples];

cfg.rmsamples = pause_samples;
cfg.channels        = 1:256;
cfg.artchan         = [241 46, 238 10]; % two dipoles
cfg.prestim         = .500; % before artefact
cfg.poststim        = .500; % after artefact 
cfg.threshold       = 3.5; % standard deviation away
cfg.lpfilter        = 'yes';
cfg.hpfilter        = 'yes';
cfg.hpfreq          = 2;
cfg.lpfreq          = 45;
cfg.demean          = 'yes';
cfg.maxartfreq      = 0.2;
cfg.badchan_threshold = 4;
component           = ft_jr_art(cfg);

%% Plot
figure;clf;
cfg.scale = [-1 1].*5*10^1;
ft_jr_art_plot(component,cfg);