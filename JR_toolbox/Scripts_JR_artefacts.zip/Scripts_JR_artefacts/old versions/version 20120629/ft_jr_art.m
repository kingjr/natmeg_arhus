function data_art = ft_jr_art(cfg)
%% data_art = ft_jr_art(cfg)
% automatically removes artefacts based on specificity (correlations) and
% sensitivity (% variance explained)
% -------------------------------------------------------------------------
% (c) 2012 Jean-Rémi KING
% contact: jeanremi.king+matlab@gmail.com
% -------------------------------------------------------------------------
% The method is based on 
%       1. finding artefact based on a given channel, or a set of channels
%       2. building a template of stereotyped artefact 
%       3. finding the combination of channels that explains most of the
%       template artefact
%       4. regressing out this combination from the data
%       5. verifying on a maximally different dataset whether it works
%
% The non-traditional features are:
%       - stereotyped artefacts are based on median across trials and not 
%       means as the M/EEG spreads in a log space, one trial can 
%       dramatically affects the steretopyed pattern. 
%       - stereotyped artefacts are normalized by the MAD, in order to 
%       avoid a few bad channels to capture most of the variance.
%       - the correlations between the principal components and the
%       artefacted channels can be used to see whether the corrected
%       topography is actually specific to the artefact. This is mainly
%       useful in MEG, as in EEG topographies are largely overlapping.
% -------------------------------------------------------------------------
% requires
%   - stats toolbox         should be change for independence
%   - Fieldtrip:            http://fieldtrip.fcdonders.nl/
%   - MNE toolbox for neuromag
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%-- modifications:
%       20120628:       (JRK) add auto rm bad channels
%       20120628:       (JRK) makes correlations optional
%       20120628:       (JRK) add dipole computation in case of multiple  
%                       artefacted channels
%       20120628:       (JRK) channel loop to avoid memory issues
%       20120627:       (JRK) randomize trials to time independent artefact
%       + optimization + simplification of continuous signal processing
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% to be done
%   - making optional checkup on independent data
%   - cleaning script: not cdg specific anymore, add commentaries, get ridd
%   off of multiple cfg
%   - add help to apply correction on future data
%   - redo the help to complete all cfg fields
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% (c) 2012 Jean-Rémi KING
% jeanremi.king+matlab@gmail.com
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ====================================================================
% ============================ parameters ============================
% ====================================================================

%-- check fields
if ~isfield(cfg,'dataset'),     error('needs cfg.dataset');                 end
if ~isfield(cfg,'artchan'),     error('cfg.artchan is needed!');            end
%------------------------- read header -----------------------------------
disp(['Read ' cfg.dataset]);
evalc('hdr = ft_read_header(cfg.dataset);');
if ~isfield(cfg,'triggerchan'), cfg.triggerchan = false;                    end
if ~isfield(cfg,'chantypes'),   cfg.chantypes   = {1:hdr.nChans};           end % cells dividing types of sensors (gradiometers, etc)
%-- finds ecg channels
if ~isfield(cfg,'headerformat'),cfg.headerformat= 'neuromag_mne';           end
if ~isfield(cfg,'dataformat'),  cfg.dataformat  = 'neuromag_mne';           end
if ~isfield(cfg,'prestim'),     cfg.prestim     = .200;                     end % time to keep before artefact
if ~isfield(cfg,'poststim'),    cfg.poststim    = 1.000;                    end % time to keep after artefact
if ~isfield(cfg,'dividetrial'), cfg.dividetrial = 1;                        end % divide the computation by n trials for memory issue
if ~isfield(cfg,'badchan_threshold'),cfg.badchan_threshold = 4;             end % automatic bad channels removal in n * MAD
if ~isfield(cfg,'corr_thresh'), cfg.corr_thresh = .05;                      end % correlation probabily between ECG and PC, 
if ~isfield(cfg,'latent_thresh'),cfg.latent_thresh=.15;                     end % minimum variance explained by component (in %)
% if ~isfield(cfg,'artnb'),       cfg.artnb       = 100;                      end % max number of artefacts to keep
if ~isfield(cfg,'artprop'),     cfg.artprop     = 3/4;                      end % max number of artefacts to keep
if ~isfield(cfg,'threshold'),   cfg.threshold   = 3.5;                      end % in STD
if ~isfield(cfg,'max_comp'),    cfg.max_comp    = 2;                        end % maximum principal components to be removed
if ~isfield(cfg,'norm'),        cfg.norm        = 'trimmean';               end % normalization using trimmean
if ~isfield(cfg,'apply_corr'),  cfg.apply_corr  = true;                     end % apply correlation analyses on components across time of specificity measure.
if ~isfield(cfg,'memory'),      cfg.memory      = 'low';                    end % memory needs
cfg.trialfun                    = 'ft_jr_ecg_trialfun';                         % get heart beat as triggers

% ====================================================================
% ========================== main function ===========================
% ====================================================================

tic
global threshold data_artchan% get threshold back from ft_jr_trialfun
threshold = cfg.threshold;


%--------------------- 1. find artefacted moments -------------------------
disp('Find artifact timing...');
evalc('cfg_art              = ft_definetrial(cfg);') % silence output
if isnan(threshold), data_art = []; warning('could not find artefact'); return; end
cfg.threshold               = threshold; % update threshold

%-- randomize trials
cfg_art.trl                 = cfg_art.trl(randperm(length(cfg_art.trl)),:);
%-- save all artefact times
cfg_art.all_trl             = cfg_art.trl;% only focus on n first artefacts (for memory and speed issues)

%----------------------- 2. Get artefacted ERP ----------------------------
disp(['Read data ...']);
cfg_art.continuous = 'no';
if ~isfield(cfg_art,'hpfilter'),        cfg_art.hpfilter = 'no'; end
if ~isfield(cfg_art,'hpfreq'),          cfg_art.hpfreq = 1; end
if ~isfield(cfg_art,'demean'),          cfg_art.demean = 'yes'; end
if ~isfield(cfg_art,'baselinewindow'),  cfg_art.baselinewindow= [0 .100]; end
evalc('data_art             = ft_preprocessing(cfg_art);'); % silence output
trl_sel                     = 1:round(cfg.artprop*length(cfg_art.trl));
data_art.time               = data_art.time{1};
data_art.trl_sel{1}         = trl_sel;
%-- automatic bad channel detection
disp('Automatic bad channel detection...');
switch cfg.memory
     case 'low'
        %-- get median absolute deviation for each channel in order to
        %prevent crap channel from exploding the variance
        chan_mad = NaN(length(data_art.label),1);
        for channel = 1:length(data_art.label)
            if channel/10 == round(channel/10),fprintf('*');end
            chan_mad(channel)    = mad(cell2mat(cellfun(@(x) x(channel,:), data_art.trial(trl_sel), 'UniformOutput', false)),1,2);
        end
        fprintf('\n');
        %-- find outlier channel
        for chantype = 1:length(cfg.chantypes)
            rm_badchan{chantype} = intersect(...
                cfg.chantypes{chantype},...
                find(chan_mad>(cfg.badchan_threshold*median(chan_mad))));
        end
        rm_badchan = [rm_badchan{:}];
end

%-- average across trials
disp([cfg.norm ' artifact ...']);
data_art.avg = robust_averaging(data_art.trial(trl_sel),cfg.norm);
data_art.rm_badchan = rm_badchan;
%-- remove bad chan
disp(['Removed ' num2str(length(rm_badchan)) ' bad channel(s)']);
data_art.avg(rm_badchan,:)  = 0;

%-- get continuous signal for plotting
data_art.artchan_trial      = data_artchan;

%---------------------- 3. Compute artefact pca ---------------------------
for chantype = 1:length(cfg.chantypes) % independently for each sensor
    disp(['Computes pca on chans ' num2str(chantype) '...']);
    [data_art.pca(chantype).coeff...
        data_art.pca(chantype).score...
        data_art.pca(chantype).latent]= princomp(data_art.avg(cfg.chantypes{chantype},:)');
    % latent into explained variance
    data_art.pca(chantype).latent = data_art.pca(chantype).latent ./ sum(data_art.pca(chantype).latent);
end



%------------------------ 4. Compute generalization -----------------------
n               = length(cfg_art.all_trl);                      %-- select independent trials
trl_sel         = (n-round((1-cfg.artprop)*n)+1):n;
data_gen        = reshape(cell2mat(data_art.trial(trl_sel)),[size(data_art.trial{1},1) size(data_art.trial{1},2) length(trl_sel)]);
data_gen_avg    = robust_averaging(data_art.trial(trl_sel),cfg.norm);
data_art.trl_sel{2}= trl_sel;


%--------------- 5. Correlate PC with artefacted channel ------------------
for chantype = 1:length(cfg.chantypes)
    disp(['Computes correlations on chans ' num2str(chantype) '...']);
    
    %-- rotate data into PC space
    components              = data_art.pca(chantype).coeff'*data_gen(cfg.chantypes{chantype},:);
    
    %-- Compute components correlation with artefacted channel
    if cfg.apply_corr
        if length(cfg_art.artchan) == 1
            data_gen_artchan = data_gen(cfg_art.artchan,:);
        elseif mod(length(cfg_art.artchan) == 1,2)==0
            data_gen_artchan = data_gen(cfg_art.artchan,:,:);
            data_gen_artchan = nanmean(data_gen_artchan(1:2:end,:)-data_gen_artchan(2:2:end,:),1);
        else
            error('the number of artefacted channels should either be 1 or a multiple of 2');
        end
        [   data_art.corr(chantype).R ...
            data_art.corr(chantype).p]  = corr(components', data_gen_artchan');
    else
        data_art.corr(chantype).R = NaN(length(cfg.channels),1);
        data_art.corr(chantype).p = NaN(length(cfg.channels),1);
    end

    %-- Find to-be-removed components 
    data_art.rm_corr{chantype}          = find(abs(data_art.corr(chantype).p(1:cfg.max_comp)) <= .05);
    data_art.rm_pca{chantype}           = find(data_art.pca(chantype).latent >= cfg.latent_thresh) ;
    data_art.rm_components{chantype}    = intersect(data_art.rm_corr{chantype}, data_art.rm_pca{chantype});
    disp(['Removed ' num2str(length(data_art.rm_components{chantype})) ' component(s) on chans ' num2str(chantype) ]);
    %-- Find to-be-kept components
    data_art.keep_components{chantype}  = setdiff(1:size(data_art.pca(chantype).coeff,1),data_art.rm_components{chantype});
    %-- Compute difference
    data_art.clear_comp{chantype}       = zeros(length(data_art.rm_components{chantype}),size(data_art.pca(chantype).coeff,1));
    data_art.clear_comp{chantype}       = cat(2,data_art.clear_comp{chantype}',data_art.pca(chantype).coeff(:,data_art.keep_components{chantype}))';
    
    %-- Compute correction on average artefact
    data_art.clear_art(cfg.chantypes{chantype},:)     = ...
        data_art.pca(chantype).coeff*...
        data_art.clear_comp{chantype}*...
        data_gen_avg(cfg.chantypes{chantype},:);
end

%---------------------------- save components -----------------------------
disp(['Export results...']);
data_art.cfg        = cfg;
data_art.cfg_art    = cfg_art;
data_art.avg2       = data_gen_avg;
data_art = rmfield(data_art, 'trial');
toc
return


function avg = robust_averaging(data,method)
%-- parameters
[n_chans n_time] = size(data{1});
n_trials = length(data);
%-- initialize
avg = NaN(n_chans,n_time);
%-- main
for channel = 1:n_chans
    % void
    if channel/10 == round(channel/10),fprintf('*');end
    % extract all trials
    y = reshape(cell2mat(cellfun(@(x) x(channel,:), data, 'UniformOutput', false)),[1 n_time, n_trials]);
    switch method
        case 'trimmean',avg(channel,:) = trimmean(y,90,'floor',3);
        case 'mean',    avg(channel,:) = nanmean(y,3);
        case 'median',  avg(channel,:) = nanmedian(y,3);
        otherwise
            error('unknown avering method');
    end
end
fprintf('\n');

