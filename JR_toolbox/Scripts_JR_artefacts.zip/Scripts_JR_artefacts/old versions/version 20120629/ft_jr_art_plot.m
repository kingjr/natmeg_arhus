function  ft_jr_art_plot(component,cfg)
% ft_jr_art_plot(component[,cfg])
% 
% plot artefact detection and correction results 
% 
% requires: ft_jr_art.m
%--------------------------------------------------------------------------
% Jean-Rémi King
%--------------------------------------------------------------------------


if nargin == 1
    cfg = [];
end
% automatically determines scale
if ~isfield(cfg,'scale'), 
    if length(component.cfg.chantypes) == 1 && strcmpi(component.label{1}(1:3), 'EEG')
        cfg.scale = [-1 1] .* 10^-3;
    elseif length(component.cfg.chantypes) == 1 && strcmpi(component.label{1}(1:3), 'MEG')
        cfg.scale = [-1 1] .* 10^-11;
    elseif length(component.cfg.chantypes) == 2 && strcmpi(component.label{1}(1:3), 'MEG')
         cfg.scale = [[-5 5] .* 10^-12; [-1 1] .* 10^-12];
    else 
        cfg.scale = [-1 1] .* 10^-3;
    end
end

clf;set(gcf,'name',component.cfg.dataset,'color','w');
%-- artefact finding
subplot(6,1,1);cla;hold on;
plot(component.artchan_trial,'b');
scatter(component.cfg_art.all_trl(component.trl_sel{1},1)-component.cfg_art.all_trl(component.trl_sel{1},3), repmat(median(component.artchan_trial),length(component.trl_sel{1}),1),'*r');
scatter(component.cfg_art.all_trl(component.trl_sel{2},1)-component.cfg_art.all_trl(component.trl_sel{2},3), repmat(median(component.artchan_trial),length(component.trl_sel{2}),1),'*g');

axis([0 length(component.artchan_trial) ylim]);
title('artefact channel and artefact detection');box off;
for chantype = 1:length(component.cfg.chantypes)
    %-- average artefact
    subplot(6,length(component.cfg.chantypes),length(component.cfg.chantypes)*1+chantype);cla;
    plot(component.time, component.avg(component.cfg.artchan,:),'b');
    axis([min(component.time) max(component.time) ylim]);
    title(['channel: ' num2str(component.cfg.artchan)]);box off;
    %-- average ERP
    subplot(6,length(component.cfg.chantypes),length(component.cfg.chantypes)*2+chantype);cla;
    imagesc(component.time,component.cfg.chantypes{chantype},component.avg(component.cfg.chantypes{chantype},:),cfg.scale(chantype,:));%normal
    title(['ERP ' num2str(chantype)]);box off;
    %-- correlation & latent values
    subplot(6,length(component.cfg.chantypes),length(component.cfg.chantypes)*3+chantype);cla; hold on;
    scatter(abs(component.corr(chantype).R),component.pca(chantype).latent, '+b');
    scatter(abs(component.corr(chantype).R(1:size(component.rm_components{chantype},1))),component.pca(chantype).latent(1:size(component.rm_components{chantype},1)), 'r', 'filled');
    axis([0 1 0 1]);box off;xlabel('R'); ylabel('Latent');
    %-- original independent
    subplot(6,length(component.cfg.chantypes),length(component.cfg.chantypes)*4+chantype);cla;
    imagesc(component.time,component.cfg.chantypes{chantype},component.avg2(component.cfg.chantypes{chantype},:),cfg.scale(chantype,:));
    title(['ERP in generalization sample ' num2str(chantype)]);box off;
    %-- correction
    subplot(6,length(component.cfg.chantypes),length(component.cfg.chantypes)*5+chantype);cla;
    imagesc(component.time,component.cfg.chantypes{chantype},component.clear_art(component.cfg.chantypes{chantype},:),cfg.scale(chantype,:));
    title(['Corrected ERP ' num2str(chantype)]);box off;
end
return