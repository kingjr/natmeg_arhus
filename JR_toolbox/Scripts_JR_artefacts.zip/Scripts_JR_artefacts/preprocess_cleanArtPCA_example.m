

tmp_file = '/home/imen/Desktop/Backup_ICM/Projects_ICM/2013_meg_ambiguity/data/preprocessed/_a120265b_component.mat';

% layout{1} = []; % fill with grad
% layout{2} = []; % fill with mag

%-- select file
cfg                 = [];
cfg.layout          = layout;
cfg.dir             = '/home/imen/Desktop/Backup_ICM/Projects_ICM/2013_meg_ambiguity/data/preprocessed/';
cfg.dataset         = '/home/imen/Desktop/Backup_ICM/Projects_ICM/2013_meg_ambiguity/data/sss/a120265b_sss.fif';
hdr              = ft_read_header(cfg.dataset);

%-- identify gradiometers and magnetometers
meg_chans           = find(cell2mat(cellfun(@(x) ~isempty(findstr('MEG',x)), hdr.label, 'UniformOutput', false)));
mag_chans           = find(cell2mat(cellfun(@(x) strcmp('1', x(end)), hdr.label, 'UniformOutput', false)));
cfg.chantypes{1}    = setdiff(meg_chans,mag_chans);
cfg.chantypes{2}    = intersect(meg_chans,mag_chans);
cfg.triggerchan     = find(cell2mat(cellfun(@(x) ~isempty(findstr('STI101',x)), hdr.label, 'UniformOutput', false)));
cfg.hdr             = hdr;

%% ecg
cfg.trials.prestim  = .700; % in s
cfg.trials.poststim = .700;
cfg.template        = 'predefined_chan'; % default
% define bad channel
cfg.trials.artchan  = find(cell2mat(cellfun(@(x) ~isempty(findstr('ECG',x)), hdr.label, 'UniformOutput', false)));
cfg.corr.threshold  = inf;
ecg_ica             = ft_jr_art(cfg);

ft_jr_art_plot(ecg_ica);

chantype = 1;
latent = ecg_ica.comp.pca(chantype).latent;
coef = ecg_ica.comp.pca(chantype).coeff;

coef_clean = coef;
bad_comp = 1:2;
coef_clean(bad_comp,:) = 0;
clean_data= coef*coef_clean'*data;
