function preprocess_ecgeog(cfg_exp, files, plot)
% [cfg_art components] = preprocess_ecgeog(cfg_exp, files, plot)
% (c) JeanRémi King 2012
if nargin == 2, plot = false;end
if ~isfield(cfg_exp,'void'), cfg_exp.void = true;end


%-- automatic printing
if cfg_exp.void, print = @(x) disp([repmat('-',1,0) ' ' x ' ' repmat('-',1,70-length(x))]);
else         print = @(x) false; end

tic
for file = 1:length(files);
    tic
    print([num2str(file) '/' num2str(length(files)) ' ' files{file}]);
    main(cfg_exp, files{file}, plot);
    toc
end
toc
return

function main(cfg_exp, file, plot)

%-- automatic printing
if cfg_exp.void, print = @(x) disp([repmat('-',1,5) ' ' x ' ' repmat('-',1,65-length(x))]);
else         print = @(x) false; end

tmp_file = [cfg_exp.main_dir 'data/preprocessed/_' file '_component.mat'];

save(tmp_file, 'cfg*'); 

%-- select file
print('1. Read header');
cfg_art                 = [];
cfg_art.layout          = cfg_exp.layout;
cfg_art.dir             = [cfg_exp.main_dir 'data/preprocessed/'];
cfg_art.dataset         = [cfg_exp.main_dir 'data/sss/' file '_sss.fif'];
evalc('hdr              = ft_read_header(cfg_art.dataset);'); % silence

%-- identify gradiometers and magnetometers
meg_chans               = find(cell2mat(cellfun(@(x) ~isempty(findstr('MEG',x)), hdr.label, 'UniformOutput', false)));
mag_chans               = find(cell2mat(cellfun(@(x) strcmp('1', x(end)), hdr.label, 'UniformOutput', false)));
cfg_art.chantypes{1}    = setdiff(meg_chans,mag_chans);
cfg_art.chantypes{2}    = intersect(meg_chans,mag_chans);
cfg_art.triggerchan     = find(cell2mat(cellfun(@(x) ~isempty(findstr('STI101',x)), hdr.label, 'UniformOutput', false)));
cfg_art.hdr             = hdr;

%% ecg
print('2. Compute ECG ICA');
cfg_art.trials.prestim  = .700; % in ms
cfg_art.trials.poststim = .700;
cfg_art.template        = 'ecg_ica';
cfg_art.corr.threshold  = inf;
ecg_ica                 = ft_jr_art(cfg_art);
save(tmp_file, 'ecg_ica', '-append');clear ecg_ica;

%% ecg
cfg_art.template        = 'predefined_chan';
print('3. Compute ECG ECG_chan');
cfg_art.trials.artchan  = find(cell2mat(cellfun(@(x) ~isempty(findstr('ECG',x)), hdr.label, 'UniformOutput', false)));
cfg_art.trials.art_prestim= .700; % in ms
cfg_art.corr.threshold  = .05;
ecg_chan                = ft_jr_art(cfg_art);
save(tmp_file, 'ecg_chan', '-append');clear ecg_chan;

%% eog vertical
print('4. Compute EOG vertical EOG_chan');
cfg_art.trials.hpfilter='no';
cfg_art.trials.lpfilter='yes';
cfg_art.trials.lpfreq  = 15;
cfg_art.trials.artchan  = find(cell2mat(cellfun(@(x) ~isempty(findstr('EOG',x)), hdr.label, 'UniformOutput', false)));
cfg_art.trials.artchan  = cfg_art.trials.artchan(1);
eog_v_chan              = ft_jr_art(cfg_art);
save(tmp_file, 'eog_v_chan', '-append');clear eog_v_chan;

%% eog horizontal
% print('4. Compute EOG vertical EOG_chan');
% cfg_art.trials.artchan  = find(cell2mat(cellfun(@(x) ~isempty(findstr('EOG',x)), hdr.label, 'UniformOutput', false)));
% cfg_art.trials.artchan  = cfg_art.trials.artchan(2);
% eog_v_chan              = ft_jr_art(cfg_art);
% save(tmp_file, 'eog_v_chan', '-append');clear eog_v_chan;
% 
% %% eog vertical based on MEG channel
% print('5. Compute EOG vertical MEG_chan');
% cfg_art.trials.threshold= 7;
% cfg_art.trials.artmethod= 'abs_mean';
% cfg_art.trials.bpfilter ='no';
% cfg_art.trials.bpfiltord =2;
% cfg_art.trials.bpfreq  = [.5 20];
% cfg_art.trials.artchan = cell2mat(cfind({'MEG0522','MEG0523','MEG0912'},hdr.label))';
% eog_v_meg          = ft_jr_art(cfg_art);
% save(tmp_file, 'eog_v_meg', '-append');clear eog_v_meg;


%% save
print('5. Get all components and save');
component = load(tmp_file);
save([cfg_exp.main_dir 'data/preprocessed/' file '_component.mat'], 'component', 'cfg*');
% 
% if plot
%     print('6. Plot components');
%     figure(1);clf;
%     ft_jr_art_plot(component.ecg_ica);
%     set(gcf,'position', [ 2   302   507   791], 'name', ['ecg ' file]);
%     figure(2);clf; 
%     ft_jr_art_plot(component.ecg_chan);
%     set(gcf,'position', [ 2   302   507   791], 'name', ['ecg ' file]);
%     figure(3);clf;
%     ft_jr_art_plot(component.eog_v_chan);
%     set(gcf,'position', [511   301   531   792], 'name', ['eog_v ' file]);
% %      figure(4);clf;
% %     ft_jr_art_plot(component.eog_v_meg);
% %     set(gcf,'position', [511   301   531   792], 'name', ['eog_v ' file]);
% %     pause(10);close all;
% end

clear component;
delete(tmp_file);

return


